import java.io.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class ExpenseManager {
    private List<Expense> expenses;

    public ExpenseManager() {
        expenses = new ArrayList<>();
    }

    // Add a new expense
    public void addExpense(Scanner scanner) {
        try {
            System.out.print("Enter Date (YYYY-MM-DD): ");
            String dateInput = scanner.nextLine();
            LocalDate date = LocalDate.parse(dateInput);

            System.out.print("Enter Category: ");
            String category = scanner.nextLine();

            System.out.print("Enter Amount: ");
            double amount = Double.parseDouble(scanner.nextLine());

            System.out.print("Enter Description: ");
            String description = scanner.nextLine();

            Expense expense = new Expense(date, category, amount, description);
            expenses.add(expense);
            System.out.println("✅ Expense added successfully.");

        } catch (DateTimeParseException e) {
            System.out.println("❌ Invalid date format. Please enter as YYYY-MM-DD.");
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid amount. Please enter a valid number.");
        } catch (Exception e) {
            System.out.println("❌ Error adding expense: " + e.getMessage());
        }
    }

    // For testing: add dummy expenses
    public void addTestExpenses() {
        expenses.add(new Expense(LocalDate.now(), "Food", 200.0, "Lunch"));
        expenses.add(new Expense(LocalDate.now(), "Transport", 100.0, "Bus fare"));
        expenses.add(new Expense(LocalDate.now(), "Bills", 400.0, "Electricity"));
    }

    // Getter to access expenses list
    public List<Expense> getExpenses() {
        return expenses;
    }

    // Method to display all expenses
    public void viewAllExpenses() {
        if (expenses.isEmpty()) {
            System.out.println("No expenses recorded.");
            return;
        }

        System.out.println("\n--- All Expenses ---");
        System.out.printf("%-12s %-12s %-10s %s\n", "Date", "Category", "Amount", "Description");
        System.out.println("--------------------------------------------------------");

        for (Expense e : expenses) {
            System.out.println(e);
        }
    }

    // Filter expenses by category
    public void filterByCategory(String category) {
        System.out.println("\n--- Expenses in Category: " + category + " ---");
        boolean found = false;

        for (Expense e : expenses) {
            if (e.getCategory().equalsIgnoreCase(category)) {
                System.out.println(e);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No expenses found for this category.");
        }
    }

    // Filter expenses by date
    public void filterByDate(LocalDate date) {
        System.out.println("\n--- Expenses on Date: " + date + " ---");
        boolean found = false;

        for (Expense e : expenses) {
            if (e.getDate().equals(date)) {
                System.out.println(e);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No expenses found for this date.");
        }
    }

    public void loadExpenses(String username) {
        String filename = username + "_expenses.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    LocalDate date = LocalDate.parse(parts[0]);
                    String category = parts[1];
                    double amount = Double.parseDouble(parts[2]);
                    String description = parts[3];
                    expenses.add(new Expense(date, category, amount, description));
                }
            }
            System.out.println("✅ Expenses loaded from file.");
        } catch (FileNotFoundException e) {
            System.out.println("No previous expenses found for this user.");
        } catch (Exception e) {
            System.out.println("❌ Error loading expenses: " + e.getMessage());
        }
    }

    public void saveExpenses(String username) {
        String filename = username + "_expenses.txt";
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (Expense e : expenses) {
                writer.printf("%s,%s,%.2f,%s\n",
                        e.getDate(), e.getCategory(), e.getAmount(), e.getDescription());
            }
            System.out.println("✅ Expenses saved to file.");
        } catch (IOException e) {
            System.out.println("❌ Error saving expenses: " + e.getMessage());
        }
    }

    public void printCategorySummary() {
        if (expenses.isEmpty()) {
            System.out.println("No expenses to summarize.");
            return;
        }

        Map<String, Double> categoryTotals = new HashMap<>();
        for (Expense e : expenses) {
            categoryTotals.put(
                    e.getCategory(),
                    categoryTotals.getOrDefault(e.getCategory(), 0.0) + e.getAmount()
            );
        }

        System.out.println("\n--- Category Summary ---");
        for (Map.Entry<String, Double> entry : categoryTotals.entrySet()) {
            System.out.printf("%-15s : %.2f\n", entry.getKey(), entry.getValue());
        }
    }

}
