import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        UserManager userManager = new UserManager();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        System.out.println("Welcome to Expense Tracker!");

        while (running) {
            System.out.println("\n1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("> ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter username: ");
                    String newUsername = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String newPassword = scanner.nextLine();

                    if (userManager.registerUser(newUsername, newPassword)) {
                        System.out.println("User registered!");
                    } else {
                        System.out.println("Username already exists!");
                    }
                    break;

                case "2":
                    System.out.print("Enter username: ");
                    String loginUsername = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String loginPassword = scanner.nextLine();

                    if (userManager.loginUser(loginUsername, loginPassword)) {
                        System.out.println("Logged in as: " + loginUsername);

                        ExpenseManager expenseManager = new ExpenseManager();
                        expenseManager.loadExpenses(loginUsername); // Load user’s expenses

                        boolean loggedIn = true;
                        while (loggedIn) {
                            System.out.println("\n1. Add Expense");
                            System.out.println("2. View All Expenses");
                            System.out.println("3. View Category Summary");
                            System.out.println("4. Filter by Category");
                            System.out.println("5. Filter by Date");
                            System.out.println("6. Save and Exit");
                            System.out.print("> ");
                            String loggedInChoice = scanner.nextLine();

                            switch (loggedInChoice) {
                                case "1":
                                    expenseManager.addExpense(scanner);
                                    break;
                                case "2":
                                    expenseManager.viewAllExpenses();
                                    break;
                                case "3":
                                    expenseManager.printCategorySummary();
                                    break;
                                case "4":
                                    System.out.print("Enter category to filter: ");
                                    String filterCat = scanner.nextLine();
                                    expenseManager.filterByCategory(filterCat);
                                    break;
                                case "5":
                                    System.out.print("Enter date to filter (YYYY-MM-DD): ");
                                    String dateInput = scanner.nextLine();
                                    try {
                                        LocalDate date = LocalDate.parse(dateInput);
                                        expenseManager.filterByDate(date);
                                    } catch (Exception e) {
                                        System.out.println("Invalid date format.");
                                    }
                                    break;
                                case "6":
                                    expenseManager.saveExpenses(loginUsername); // Save before exit
                                    loggedIn = false;
                                    break;
                                default:
                                    System.out.println("Invalid option. Try again.");
                            }
                        }
                    } else {
                        System.out.println("Invalid credentials!");
                    }
                    break;

                case "3":
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }

        scanner.close();
    }
}
